USE SIBW;

DROP TABLE Usuarios;
DROP TABLE Actividad;
DROP TABLE Palabras_prohibidas;
DROP TABLE Comentarios;
DROP TABLE Galeria;