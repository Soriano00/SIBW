USE SIBW;

SELECT * FROM Usuarios;
SELECT * FROM  Actividad;
SELECT * FROM Palabras_prohibidas;
SELECT * FROM  Comentarios;
SELECT * FROM  Galeria;