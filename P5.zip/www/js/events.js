const deleteEvent = (idEvent) => {
    window.location.replace(`../php/delete_event.php?ev=${idEvent}`);
}
