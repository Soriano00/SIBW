<?php
  require_once "/usr/local/lib/php/vendor/autoload.php";
  include("php/model/bd.php");
  
  session_start();
  $loader = new \Twig\Loader\FilesystemLoader('templates');
  $twig = new \Twig\Environment($loader);
  
  function startWith($string, $query){
    return substr($string, 0, strlen($query)) === $query;
  }

  $uri = $_SERVER['REQUEST_URI'];
  $unprotected = array("/login", "/register", "add_user.php", "login_user.php");


  //Proteger rutas
  if(!$_SESSION["email"] && !in_array($uri, $unprotected) )
  {
    header('Location:/login');
    return;
  }


  //Proteger rutas admin
  if ( isset($_SESSION["email"]) ){
    $role = $_SESSION["email"][1];

    if (
      ($role !== "SUPER") && ($uri === "/admin/usuarios") || ($role !== "SUPER") && ($uri === "/admin/eventos")  
      || ($role !== "SUPER" && $role !== "MODERADOR") && ($uri === "/admin/eventos")
    ){
      header('Location:/');
      return;
    }

  }

  //Router

  //Events
  if (startWith($uri, "/add_comment.php")){
    include("php/add_comment.php");
  } else if (startWith($uri, "/evento/imprimir")){
    include("php/actividad_imprimir.php");
  } else if (startWith($uri, "/evento")){
    include("php/actividad.php");
  }


  //Admin
  else if(startWith($uri, "/admin/usuarios")){
    include("php/all_users.php");
  }
  else if(startWith($uri, "/admin/eventos")){
    include("php/all_events.php");
  }
  else if(startWith($uri, "/admin/evento")){
    include("php/edit_actividad.php");
  }

  //Scripts
  else if(startWith($uri, "/delete_comment.php")){
    include("php/delete_comment.php");
  } 
  else if(startWith($uri, "/update_comment.php")){
    include("php/update_comment.php");
  } 
  else if(startWith($uri, "/delete_user.php")){
    include("php/delete_user.php");
  }
  else if(startWith($uri, "/change_user_role.php")){
    include("php/change_user_role.php");
  }
  else if(startWith($uri, "/delete_event.php")){
    include("php/delete_event.php");
  } 
  else if(startWith($uri, "/add_event.php")){
    include("php/add_event.php");
  } 
  else if(startWith($uri, "/update_event.php")){
    include("php/update_event.php");
  } 


  //Profile
  else if(startWith($uri, "/perfil")){
    include("php/profile.php");
  } 
  else if(startWith($uri, "/change_user_info.php")){
    include("php/change_user_info.php");
  } 
  

  //Login-register
  else if(startWith($uri, "/add_user.php")){
    include("php/add_user.php");
  }   
  else if(startWith($uri, "/login_user.php")){
    include("php/login_user.php");
  } 
  else if(startWith($uri, "/login")){
    include("php/login.php");
  } 
  else if(startWith($uri, "/register")){
    include("php/register.php");
  } 
  else if(startWith($uri, "/logout.php")){
    include("php/logout.php");
  } 
   
   
  //Default
  else{
    $actividades = getActividades();

    
    echo $twig->render('portada.html',[ 'actividades' => $actividades , 'role' => $role]);
  }
  
?>