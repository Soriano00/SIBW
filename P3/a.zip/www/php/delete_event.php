<?php
    include("php/model/bd.php");
    session_start();

    $uri = $_SERVER['REQUEST_URI'];


    if(isset($_GET['event'])){
        $idEvent = $_GET['event'];
    }else{
        $idEvent = -1;
    }

    //Check permits
    if($_SESSION["email"][1] !== "SUPER" && $_SESSION["email"][1] !== "MODERADOR")
    {
        header("Location:/admin/eventos");
        return;
    }


    //DELETE
    deleteActividad($idEvent);
    header("Location:/admin/eventos");
?>