<?php
  require_once "/usr/local/lib/php/vendor/autoload.php";



  $mysqli = null;

  
  function startMySqli() {
    global $mysqli;

    $mysqli =  new mysqli ("database", "alex", "alex", "SIBW");

    if ( $mysqli->connect_errno) {
      echo ("Fallo al conectar: " . $mysqli->connect_errno);
      return null;
    } 

    return $mysqli;
  }
    // Actividades
    function getActividad($idActividad) {
      global $mysqli;
      
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("SELECT Id_Actividad, photo, title, price, date, autor, descr FROM Actividad WHERE Id_Actividad=?");
      $stmt->bind_param("i", $idActividad);
      $stmt->execute();
      $actividad = $stmt->get_result()->fetch_assoc();
      $stmt->close();

      return $actividad;
    }

    function getActividades() {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }    
      
      $stmt = $mysqli->prepare("SELECT Id_Actividad, photo, title, price, date FROM Actividad");
      $stmt->execute();
      $actividades = $stmt->get_result()->fetch_all();
      $stmt->close();
      
      return $actividades;
    }


    function getActividadBasicInfo() {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      } 
      
      $stmt = $mysqli->prepare("SELECT Id_Actividad, title, price, date FROM Actividad");
      $stmt->execute();
      $actividades = $stmt->get_result()->fetch_all();
      $stmt->close();
      
      return $actividades;

    }

    function deleteActividad($idActividad) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("DELETE FROM Actividad WHERE Id_Actividad=?");
      $stmt->bind_param("i", $idActividad);
      $stmt->execute();
      $stmt->close();
    }

    function getGaleria ($idActividad) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }   
      
      $stmt = $mysqli->prepare("SELECT photo FROM Galeria WHERE Id_Actividad=?");
      $stmt->bind_param("i", $idActividad);
      $stmt->execute();
      $gallery = $stmt->get_result()->fetch_all();
      $stmt->close();

      $gallery = array_map(function($image) {return $image[0];}, $gallery);
      return $gallery;
    }

    function getGaleriaCompleta ($idActividad) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }   
      
      $stmt = $mysqli->prepare("SELECT photo, Id FROM Galeria WHERE Id_Actividad=?");
      $stmt->bind_param("i", $idActividad);
      $stmt->execute();
      $gallery = $stmt->get_result()->fetch_all();
      $stmt->close();

      return $gallery;
    }

    function addToGaleria( $idActividad, $photo ){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  
      $stmt = $mysqli->prepare("INSERT INTO Galeria 
                                (Id_Actividad, photo) 
                                VALUES (?, ?)"
      );
      $stmt->bind_param("is", $idActividad, $photo);
      $stmt->execute();
      $stmt->close();
    }

    function deleteFromGaleria ( $delete_gallery ) {
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  

      // Delete all tags
      if ( !empty($delete_gallery) ) {
        foreach ( $delete_gallery as $idGaleria ) {
          $stmt = $mysqli->prepare("DELETE FROM Galeria WHERE Id=?");
          $stmt->bind_param("i", $idGaleria);
          $stmt->execute();
          $stmt->close();
        }
      }

    }

    function addActividad( $title, $photo, $price, $date, $autor, $descr ){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  
      $stmt = $mysqli->prepare("INSERT INTO Actividad 
                                ( title, photo, price, date, autor, descr) 
                                VALUES ( ?, ?, ?, ?, ?, ?)"
      );
      $stmt->bind_param("sssssi", $title, $photo, $price, $date, $autor, $descr);
      $stmt->execute();
      $stmt->close();

    }


    function searchActividades ( $query ) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }    
      $query = '%' . $query . '%';
      
      $stmt = $mysqli->prepare("SELECT Id_Actividad, title FROM evenActvidadts
                               WHERE title LIKE ?
                               OR description LIKE ?"); 
      $stmt->bind_param("ss", $query, $query );
      $stmt->execute();
      $actividades = $stmt->get_result()->fetch_all();
      $stmt->close();
      
      return $actividades;
    }


    function updateActividad($idActividad, $title, $price, $date, $description){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  
      $stmt = $mysqli->prepare ("UPDATE Actividad SET title=?, price=?, date=?, descr=? WHERE Id_Actividad=?");
      $stmt->bind_param("ssssii", $title, $price, $date, $description);
      $stmt->execute();
      //Update
      $stmt = $mysqli->prepare ("SELECT Id_Actividad FROM Actividad WHERE Id_Actividad=?");
      $stmt->bind_param("i", $idActividad);
      $stmt->execute();
      $stmt->close();
    }


    function updatePhoto($idActividad, $photo){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  
      $stmt = $mysqli->prepare ("UPDATE Actividad SET photo=? WHERE Id_Actividad=?");
      $stmt->bind_param("si",$photo, $idActividad);
      $stmt->execute();
      $stmt->close();
    }




    // Comments
    function getComentarios($idActividad) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }     
      
      $stmt = $mysqli->prepare("SELECT author, date, comment, Id_Comentario FROM Comentarios WHERE Id_Actividad=?");
      $stmt->bind_param("i", $idActividad);
      $stmt->execute();
      $comments = $stmt->get_result()->fetch_all();
      $stmt->close();

      return $comments;
    }

    function getAllComentarios () {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }     
      
      // Get all events
      $stmt = $mysqli->prepare("SELECT Id_Actividad, title FROM Actividad");
      $stmt->execute();
      $actividades = $stmt->get_result()->fetch_all();
      $stmt->close();

      // Get all comments
      for ( $i = 0; $i < count($actividades); $i++) {
        array_push($actividades[$i], getComentarios($actividades[$i][0]) );
      }

      return $actividades;
    }

    function addComentario($idActividad, $comment, $author){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  
      
      $stmt = $mysqli->prepare("INSERT INTO Comentarios (Id_Actividad, comment, date, author) VALUES (?,?,NOW(),?)");
      $stmt->bind_param("iss", $idActividad, $comment, $author);
      $stmt->execute();
      $stmt->close();
    }

    function deleteComentarios ( $idComment ) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      

      $stmt = $mysqli->prepare("DELETE FROM Comentarios WHERE id=?");
      $stmt->bind_param("i", $idComment );
      $stmt->execute();
      $stmt->close();
    }

    
    function updateComentarios ( $idComment, $comment ) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      

      $stmt = $mysqli->prepare("UPDATE Comentarios SET comment=? WHERE id=?");
      $stmt->bind_param("si", $comment, $idComment );
      $stmt->execute();
      $stmt->close();
    }

    // Banned words
    function getPalabras_prohibidas() {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }   
      
      $stmt = $mysqli->prepare("SELECT palabra FROM Palabras_prohibidas");
      $stmt->execute();
      $banned = $stmt->get_result()->fetch_all();
      $stmt->close();

      $banned = array_map(function($word) {return $word[0];}, $banned);
      return $banned;
    }

    // Users
    function getUsuarios() {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }    
      
      $stmt = $mysqli->prepare("SELECT Id_Usuario, email FROM Usuarios");
      $stmt->execute();
      $usuarios = $stmt->get_result()->fetch_all();
      $stmt->close();
      
      return $usuarios;
    }

    function getUsuario($email) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("SELECT nombre, email, password, Id_Usuario FROM Usuarios WHERE email=?");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $usuario = $stmt->get_result()->fetch_assoc();
      $stmt->close();

      return $usuario;
    }

    function getUsuarioId($idUsuario) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("SELECT nombre, email, password, Id_Usuario FROM Usuarios WHERE Id_Usuario=?");
      $stmt->bind_param("i", $idUsuario);
      $stmt->execute();
      $usuario = $stmt->get_result()->fetch_assoc();
      $stmt->close();

      return $usuario;
    }

    function addUsuario($email, $nombre, $password) {
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }  
      $encryptedPass = password_hash( $password, PASSWORD_DEFAULT );

      $stmt = $mysqli->prepare("INSERT INTO Usuarios (email, nombre, password) VALUES (?,?,?)");
      $stmt->bind_param("sss", $email, $name, $encryptedPass);
      $stmt->execute();
      $stmt->close();
      $mysqli->next_result();
    }

    function deleteUsuario($idUser){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("DELETE FROM Usuarios WHERE Id_Usuario=?");
      $stmt->bind_param("i", $idUser);
      $stmt->execute();
      $stmt->close();
    }


    
    function changeRole($idUser, $role){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("UPDATE Usuarios SET role=? WHERE Id_Usuario=?");
      $stmt->bind_param("si", $role, $idUser);
      $stmt->execute();
      $stmt->close();
    }


    function changeUser($idUser, $name, $email){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }      
      
      $stmt = $mysqli->prepare("UPDATE Usuarios SET nombre=?, email=? WHERE Id_Usuario=?");
      $stmt->bind_param("ssi", $name, $email, $idUser);
      $stmt->execute();
      $stmt->close();


      //Update session
      session_start();
      $role = $_SESSION['email'];
      unset ($_SESSION['email']);
      $_SESSION['email'] = array($email, $role);
    }


    function changePass($idUser, $password){
      global $mysqli;
      if (!$mysqli){
        if ( !($mysqli = startMySqli() )) return;
      }   
      $encryptedPass = password_hash($password, PASSWORD_DEFAULT);

      $stmt = $mysqli->prepare("UPDATE Usuarios SET contraseña=? WHERE Id_Usuario=?");
      $stmt->bind_param("si", $encryptedPass, $idUser);
      $stmt->execute();
      $stmt->close();
    }
?>