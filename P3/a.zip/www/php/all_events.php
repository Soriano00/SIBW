<?php
    include("php/model/bd.php");
    session_start();
    $uri = $_SERVER['REQUEST_URI'];

    if( ($_SESSION["email"][1] !== "SUPER") &&  ($_SESSION["email"][1] !== "MODERADOR"))
    {
        header("location:javascript://gistory.go(-1)");
        return;
    }

    echo $twig-> render("all_events.hrml", [
        'email' => $_SESSION["email"][0],
        'role' => $_SESSION["email"][1],
        'actividades' => getActividadBasicInfo() 
    ]);

?>