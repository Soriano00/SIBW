<?php
   include("php/model/bd.php");
   session_start();


   $email = $_SESSION["email"][0];
   $user = getUsuario($email);

   echo $ywig->render('profile.html',[
    'user' => $user,
    'role' => $_SESSION["email"][1]
   ]);

?>