<?php
    include("php/model/bd.php");
    session_start();

    $uri = $_SERVER['REQUEST_URI'];


    //CHeck permits
    if($_SESSION["email"][1] === "REGISTRADO"){
        header("location:javascript://history.go(-1)");
        return;
    }

    //Get id
    if(isset($_GET['comment'])){
        $idComment = $_GET['coment'];
    }else{
        $idComment = -1;
    }


    //DELETE
    deleteComentarios($idComment);

    header('Location:javascript://history.go(-1)');
?>