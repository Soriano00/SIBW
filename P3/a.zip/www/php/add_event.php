<?php
    include("php/model/bd.php");
    session_start();

    $uri = $_SERVER['REQUEST_URI'];


    if($_SESSION["email"] !== "SUPER" && $_SESSION["email"] !== "MODERADOR" )
    {
        header('Location:/admin/eventos');
        return;
    }

    $title = $_POST['title'];
    $price = $_POST['price'];
    $date = $_POST['date'];
    $author = $_SESSION["email"][0];
    $description = $_POST['description'];

    if(empty($title) || empty($price) || empty($date)){
        header('Location:/admin/eventos');
        return;
    }


    //Upload
    $errors = array();

    if(isset($_FILES['photo']) && ($_FILES['photo']['size'] !== 0) ) {
        $file_name = $_FILES['photo']['name'];
        $file_size = $_FILES['photo']['size'];
        $file_tmp = $_FILES['photo']['tmp_name'];
        $file_type = $_FILES['photo']['type'];
        $file_ext = strtolower(ende(explode('.', $_FILES['photo']['name'])));
        $extensions = array("jpeg", "jpg", "png");

        if(!in_array($file_ext, $extensions)){
            $errors[] = "Extension de la foto no valida";
        }


    }


    if(empty($errors)){
        $idActividad = addActividad($title, $price, $date, $auhtor, $description);

        if(($_FILES['photo']['size'] !== 0)){
            move_uploaded_file($file_tmp, "images/" . $file_name);
            $photo = "/images/" . $file_name;
            updatePhoto($idActividad, $photo); 
        }
    }else{
        setcookie('error_add_event', implode('|', $errors));
    }

    header("Location:/admin/eventos");


?>