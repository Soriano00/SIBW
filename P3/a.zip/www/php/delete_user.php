<?php
    include("php/model/bd.php");
    session_start();

    $uri = $_SERVER['REQUEST_URI'];


    if(isset($_GET['user'])){
        $idUser = $_GET['user'];
    }else{
        $idUser = -1;
    }

    $user = getUsuarioId($idUser);


    //Check permits
    if($_SESSION["email"][0] !== $user['email'] && $_SESSION["email"][1] !== "SUPER")
    {
        setcookie('error_delete_user', "No es posible borrar al usuario");
        header("Location:/admin/usuarios");
        return;
    }

    if(isset($_COOKIE['error_delete_user']))
        setcookie('error_delete_user');

    //DELETE
    deleteUsuario($idUser);
    header("Location:/admin/usuarios");
?>