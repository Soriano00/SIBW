<?php
    include("php/model/bd.php");
    session_start();

    $uri = $_SERVER['REQUEST_URI'];

    if( $_SERVER['REQUEST_METHOD'] !== 'POST'){
        header('Location:/login');
        exit();
    }

    if(isset($_COOKIE['error_update']))
        setcookie('error_update');

    //Get user
    $email = $_SESSION["email"][0];
    $user = getUsuario($email);

    //Get data
    $name = $_POST['nombre'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    //Validate
    $changePass = !empty($password);

    if(!$user){
        header('Location:/login.php');
        return;
    }

    //Update

    if($changePass){
        changePass($user['Id_Usuario'], $password);
    }else {
        if(empty($name))
            $name = $user['nombre'];
        
        if(empty($email))
            $email = $user['email'];

        $changingEmail = ($email !== $user['email']);
        $error = false;

        if($changingEmail)
            if(getUsuario($email))
                $error = true;

        if($error)
            setcookie('error_update', "El email no es válido");
        else{
            changeUser($user['Id_Usuario']);
            unset($_SESSION['email']);
            $_SESSION['email'] = array($email,$user['role']);
        }

    }

    header('Location:/perfil');
?>