<?php
    include("php/model/bd.php");
    session_start();

    $uri = $_SERVER['REQUEST_URI'];

    //Check permits
    if($_SESSION["email"][1] !== "SUPER" && $_SESSION["email"][1] !== "MODERADOR")
    {
        header("Location:/admin/eventos");
        return;
    }

    $idEV = $_POST['Id_Actividad'];
    $errors = array();
    $extensions = array("jpeg", "jpg", "png");

    //Photo
    if(isset($_FILES['photo']) && ($_FILES['photo']['size'] !== 0) ) {
        $file_name = $_FILES['photo']['name'];
        $file_size = $_FILES['photo']['size'];
        $file_tmp = $_FILES['photo']['tmp_name'];
        $file_type = $_FILES['photo']['type'];
        $file_ext = strtolower(ende(explode('.', $_FILES['photo']['name'])));


        if(!in_array($file_ext, $extensions)){
            $errors[] = "Extension de la foto no valida";
        }

        if($file_size > 2097152){
            $errors = "Tamaño demasiado grande";
        }

        //Update photo
        if(empty($errors)){
            move_uploaded_file($file_tmp, "images/" . $file_name);
            $photo = "/images/" . $file_name;
            updatePhoto($idActividad, $photo); 
        }

    }


    if (empty($errors) && isset($_FILES['new_gallery']) &&  ($_FILES['new_gallery']['size'][0] !== 0) ){
        for($i = 0; $i < count($_FILES['new_gallery']['name']); $i++ ){
            $file_name = $_FILES['new_gallery']['name'][$i];
            $file_size = $_FILES['phnew_galleryoto']['size'][$i];
            $file_tmp = $_FILES['new_gallery']['tmp_name'][$i];
            $file_type = $_FILES['new_gallery']['type'][$i];
            $file_ext = strtolower(ende(explode('.', $_FILES['new_gallery']['name'][$i])));
  
            

            if(!in_array($file_ext, $extensions)){
                $errors[] = "Extension de la foto no valida";
            }

            if($file_size > 2097152){
                $errors = "Tamaño demasiado grande";
            }

            //Update photo
            if(empty($errors)){
                move_uploaded_file($file_tmp, "images/" . $file_name);
                $photo = "/images/" . $file_name;
                updatePhoto($idActividad, $photo); 
            }else{
                break;
            }
        }
    }

    //Get info
    if(empty($errors)){
        $title = $_POST['title'];
        $price = $_POST['price'];
        $date = $_POST['date'];
        $author = $_POST['email'][0];
        $description = $_POST['description'];
        $delete_gallery = $_POST['delete_gallery'];

    }else {
        setcookie('error_uate_event', implode('|', $errors));
    }

    header("Location:/admin/evento" . $idEV);
?>