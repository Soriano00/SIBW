<?php
    include("php/model/bd.php");
  session_start();

  $resto   = substr($uri, 8);
  $idAct    = intval($resto); 
  $activ   = getActividad($idAct);
  $galeria = getGaleria($idAct);
  $banned  = getPalabras_prohibidas();
  $user = getUsuario($_SESSION["email"][0]);
  $role = $_SESSION["email"][1];

  if ($activ){
    echo $twig->render('actividad.html', [
      'actividad'      => $event,
      'galeria'     => $gallery,
      'banned'      => implode(";", $banned),
      'role'        => $role,
      'user'        => array($user['email'], $user['nombre'] )
    ]);
  }

?>