<?php
    include("php/model/bd.php");
  session_start();

  $resto   = substr($uri, 17);
  $idAct    = intval($resto); 
  $activ   = getActividad($idAct);
  $galeria = getGaleria($idAct);

  if ($activ && ($role === "SUPER" || $role === "MODERADOR")){
    echo $twig->render('actividad-imprimir.html', [
      'actividad'      => $event,
      'galeria'     => $gallery
    ]);
  }

?>