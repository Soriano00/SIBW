<?php
    include("php/model/bd.php");
    session_start();
    

    $users = getUsuarios();
    $roles = array('REGISTRADO', 'MODERADOR', 'SUPER');
   
    echo $twig-> render("all_users.hrml", [
        'users' => $users,
        'role' => $_SESSION["email"][1],
        'roles' => $roles 
    ]);

?>