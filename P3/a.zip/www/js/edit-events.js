
const deleteActividad = ( idActividad ) => {
    window.location.replace(`delete_actividad.php?actividad=${idActividad}`)
}


const editActividad = ( idActividad ) => {
    window.location.href = `/admin/actividad/${ idActividad }`
}


//Add
const submitButton = document.getElementById("submit-button")
const photoInput = document.getElementsByName('photo')[0]
const titleInput = document.getElementsByName('title')[0]
const priceInput = document.getElementsByName('price')[0]
const dateInput = document.getElementsByName('date')[0]
const descriptionInput = document.getElementsByName('description')[0]


submitButton.onclick = (actividad) => {
    let error = ""

    if(titleInput.value === '')
        error = "Titulo no válido"
    else if (dateInput.value === '')
        error = "Fecha no válida"
    else if (priceInput.value === '')
        error = "Precio no válido"

    if (error) {

        actividad.preventDefault()

        Swal.fire({
            title: 'Error',
            text: error,
            icon: 'error'
        })



    }
}