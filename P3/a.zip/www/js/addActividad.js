import {modal} from './modal.js'
import {deleteCookie} from './deleteCookie.js'
import {GetCookie} from './getCookie.js'

const buttonModal = document.getElementById('add_actividad')

const error = GetCookie("error_add_actividad")

if (error){
    Swal.fire({
        title: 'Error',
        text: error,
        icon: 'error'
    })

    deleteCookie("error_add_actividad")
}

buttonModal.onclick = () => {
    modal.style.display = "flex"
}